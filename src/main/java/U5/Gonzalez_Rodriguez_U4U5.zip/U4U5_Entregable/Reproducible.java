package U5.U4U5_Entregable;

public interface Reproducible {

  void play();

  void pause();

  void stop();
}
